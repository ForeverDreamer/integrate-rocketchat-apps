export type UIType = 'modal' | 'buttons';
